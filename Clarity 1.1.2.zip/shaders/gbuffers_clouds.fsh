#version 330 compatibility

uniform sampler2D gtexture;

in vec2 texcoord;
in vec4 glcolor;

#define CLOUD_TYPE 1 // [0 1 2]

/* DRAWBUFFERS:0 */
layout(location = 0) out vec4 color;

void main() {
    #if CLOUD_TYPE == 2
        discard;
    #else
        vec4 tex = texture(gtexture, texcoord);

        #if CLOUD_TYPE == 0
            color = vec4(1.0, 1.0, 1.0, 0.8);
        #elif CLOUD_TYPE == 1
            color = tex * glcolor;
            color.a *= 0.5;
        #endif

        if (color.a < 0.1) {
            discard;
        }
    #endif
}