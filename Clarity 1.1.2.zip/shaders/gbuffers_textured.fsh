#version 330 compatibility

uniform sampler2D gtexture;

in vec2 texcoord;
in vec4 glcolor;

layout(location = 0) out vec4 color;

void main() {
    vec4 texColor = texture(gtexture, texcoord);

    float boost = 1.75;
    vec3 brightColor = min(glcolor.rgb * boost, vec3(1.0));

    texColor.rgb *= brightColor;

    texColor.a *= glcolor.a;

    if (texColor.a < 0.1) discard;

    color = texColor;
}
