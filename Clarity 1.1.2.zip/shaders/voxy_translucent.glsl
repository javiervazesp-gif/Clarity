// Define the output buffer (matches colortex0)
layout(location = 0) out vec4 outColor;

void voxy_emitFragment(VoxyFragmentParameters parameters) {
    // parameters.sampledColour is the block texture
    // parameters.tinting is the AO and biome tint
    vec4 color = parameters.sampledColour * parameters.tinting;
    
    // Fix: Modern GLSL requires writing to an 'out' variable, not gl_FragData
    if (color.a < 0.1) discard;

    outColor = color;
}