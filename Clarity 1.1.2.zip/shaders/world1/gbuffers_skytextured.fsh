#version 120

varying vec4 texcoord;
varying vec4 color;

uniform sampler2D texture;

void main() {
    // We output a color with 0 alpha (invisible), effectively deleting the grain.
    gl_FragData[0] = vec4(0.0, 0.0, 0.0, 0.0);
}