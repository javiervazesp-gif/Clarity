#version 450
#include "/prelude/core.glsl"

uniform int renderStage;
uniform mat4 modelViewMatrix, projectionMatrix;

in vec3 vaPosition;
in vec4 vaColor;

out VertexData {
    layout(location = 0, component = 0) flat vec3 tint;
} v;

void main() {
    gl_Position = proj_mmul(projectionMatrix, rot_trans_mmul(modelViewMatrix, vaPosition));
    v.tint = vaColor.rgb; 
}